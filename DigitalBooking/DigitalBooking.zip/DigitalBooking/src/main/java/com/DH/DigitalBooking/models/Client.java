package com.DH.DigitalBooking.models;

public class Client extends User {




}
